#!/usr/bin/env python3
"""
Refresh reviewer resource markdown files from source repositories.

The script reads a JSON manifest describing one or more repositories and the
markdown files or sections to extract into .github/resources.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


HEADING_PATTERN = re.compile(r"^(#{1,6})\s+(.*?)\s*$")
DEFAULT_CONFIG_PATH = Path(".github/resources/resource_sources.json")


class ResourceSyncError(Exception):
    """Raised when resource sync configuration or execution fails."""


@dataclass(frozen=True)
class ResourceSpec:
    name: str
    repo: str
    ref: str | None
    source: Path
    output: Path
    heading: str | None = None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Update .github/resources markdown files from configured repositories."
    )
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_PATH),
        help="Path to the JSON manifest describing source repositories.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate configuration and show planned updates without writing files.",
    )
    return parser.parse_args()


def normalize_heading(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().strip("#")).casefold()


def extract_markdown_section(content: str, heading: str) -> str:
    lines = content.splitlines()
    normalized_target = normalize_heading(heading)
    start_index: int | None = None
    start_level: int | None = None

    for index, line in enumerate(lines):
        match = HEADING_PATTERN.match(line)
        if not match:
            continue

        level = len(match.group(1))
        title = normalize_heading(match.group(2))
        if title == normalized_target:
            start_index = index
            start_level = level
            break

    if start_index is None or start_level is None:
        raise ResourceSyncError(f'Heading "{heading}" was not found in source markdown.')

    end_index = len(lines)
    for index in range(start_index + 1, len(lines)):
        match = HEADING_PATTERN.match(lines[index])
        if not match:
            continue
        level = len(match.group(1))
        if level <= start_level:
            end_index = index
            break

    section = "\n".join(lines[start_index:end_index]).strip()
    if not section:
        raise ResourceSyncError(f'Heading "{heading}" resolved to an empty section.')

    return section + "\n"


def run_git_command(args: list[str], cwd: Path | None = None) -> None:
    result = subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "git command failed"
        raise ResourceSyncError(message)


def clone_repo(repo: str, ref: str | None, destination: Path) -> None:
    command = ["git", "clone", "--depth", "1"]
    if ref:
        command.extend(["--branch", ref])
    command.extend([repo, str(destination)])
    run_git_command(command)


def resolve_repo_value(repo_value: str, workspace_root: Path) -> str:
    if "://" in repo_value or repo_value.startswith("git@"):
        return repo_value

    repo_path = Path(repo_value)
    if repo_path.is_absolute():
        return str(repo_path)

    return str((workspace_root / repo_path).resolve())


def load_manifest(config_path: Path, workspace_root: Path) -> tuple[Path, tuple[ResourceSpec, ...]]:
    try:
        manifest = json.loads(config_path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ResourceSyncError(f"Config file not found: {config_path}") from exc
    except json.JSONDecodeError as exc:
        raise ResourceSyncError(f"Config file is not valid JSON: {exc}") from exc

    resources_dir_value = manifest.get("resources_dir", ".github/resources")
    resources_dir_path = Path(str(resources_dir_value))
    resources_dir = (
        resources_dir_path.resolve()
        if resources_dir_path.is_absolute()
        else (workspace_root / resources_dir_path).resolve()
    )
    resources_data = manifest.get("resources")
    if not isinstance(resources_data, list):
        raise ResourceSyncError('Manifest must define a "resources" array.')

    resource_specs: list[ResourceSpec] = []
    for resource_data in resources_data:
        if not isinstance(resource_data, dict):
            raise ResourceSyncError("Each resource entry must be an object.")
        if resource_data.get("enabled", True) is False:
            continue

        name = str(resource_data.get("name") or resource_data.get("output") or "unnamed-resource")
        repo = resource_data.get("repo")
        if not repo:
            raise ResourceSyncError(f'Resource entry "{name}" is missing a "repo" value.')

        source = resource_data.get("source")
        output = resource_data.get("output")
        if not source or not output:
            raise ResourceSyncError(
                f'Resource entry "{name}" requires "source" and "output" values.'
            )

        resource_specs.append(
            ResourceSpec(
                name=name,
                repo=resolve_repo_value(str(repo), workspace_root),
                ref=str(resource_data["ref"]) if resource_data.get("ref") else None,
                source=Path(str(source)),
                output=Path(str(output)),
                heading=str(resource_data["heading"]) if resource_data.get("heading") else None,
            )
        )

    return resources_dir, tuple(resource_specs)


def render_output(content: str, resource_spec: ResourceSpec) -> str:
    metadata = [
        "<!-- Generated by scripts/update_resources.py.",
        f"Source repo: {resource_spec.repo}",
        f"Source file: {resource_spec.source.as_posix()}",
    ]
    if resource_spec.ref:
        metadata.append(f"Source ref: {resource_spec.ref}")
    if resource_spec.heading:
        metadata.append(f"Source heading: {resource_spec.heading}")
    metadata.append("-->\n")
    return "\n".join(metadata) + content.lstrip()


def ensure_output_path(resources_dir: Path, output: Path) -> Path:
    output_path = (resources_dir / output).resolve()
    if resources_dir.resolve() not in output_path.parents and output_path != resources_dir.resolve():
        raise ResourceSyncError(f"Output path escapes resources directory: {output}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    return output_path


def sync_resource(resources_dir: Path, resource_spec: ResourceSpec, dry_run: bool) -> str:
    with tempfile.TemporaryDirectory(prefix="reviewer-resources-") as temp_dir:
        checkout_dir = Path(temp_dir) / "repo"
        clone_repo(resource_spec.repo, resource_spec.ref, checkout_dir)

        source_path = checkout_dir / resource_spec.source
        if not source_path.exists():
            raise ResourceSyncError(
                f'Source file was not found for "{resource_spec.name}": {resource_spec.source.as_posix()}'
            )

        raw_content = source_path.read_text(encoding="utf-8")
        content = (
            extract_markdown_section(raw_content, resource_spec.heading)
            if resource_spec.heading
            else raw_content
        )
        output_path = ensure_output_path(resources_dir, resource_spec.output)
        rendered = render_output(content, resource_spec)

        if not dry_run:
            output_path.write_text(rendered, encoding="utf-8", newline="\n")

        return f"{resource_spec.name}: {resource_spec.source.as_posix()} -> {output_path}"


def main() -> int:
    args = parse_args()
    workspace_root = Path.cwd().resolve()
    config_path = Path(args.config).resolve()

    try:
        resources_dir, resource_specs = load_manifest(config_path, workspace_root)
        if not resource_specs:
            raise ResourceSyncError("No enabled resources were found in the manifest.")

        for resource_spec in resource_specs:
            result = sync_resource(resources_dir, resource_spec, dry_run=args.dry_run)
            prefix = "[dry-run]" if args.dry_run else "[updated]"
            print(f"{prefix} {result}")
    except ResourceSyncError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())