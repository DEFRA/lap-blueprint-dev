# Quick Start Guide - Reviewer Agent

## 5-Minute Setup

This file is the source of truth for using and maintaining the Reviewer Agent workspace.

Get your Reviewer Agent running in VS Code right away.

## Overview

The Reviewer Agent helps delivery teams assess AI agents against five DEFRA compliance areas:

1. System Type Selection
2. Responsible Design Principles
3. Governance & Oversight
4. Technical & Delivery Guidance
5. Security & Integration

## Workspace Layout

```text
reviewer/
├── QUICKSTART.md                    ← This file
├── .github/
│   ├── copilot-instructions.md      ← Workspace-level agent instructions
│   ├── agents/
│   │   └── reviewer.md              ← @Reviewer agent definition
│   ├── skills/
│   │   └── generate-report/
│   │       ├── generate-report.md   ← Skill: generate HTML compliance report
│   │       └── scripts/
│   │           └── generate_report.py
│   ├── resources/                   ← DEFRA standards and resource sync manifest
│   │   ├── ai-checklist.md
│   │   ├── right-approach.md
│   │   ├── responsible-design-principles.md
│   │   ├── governance-oversight.md
│   │   ├── technical-delivery-guidance.md
│   │   └── resource_sources.json
│   └── templates/                   ← Agent submission templates
│       ├── compliant-agent-template.md  ← Fill this in for your agent
│       └── example-compliant-agent.md
├── scripts/
│   └── update_resources.py          ← Refresh .github/resources from source repos
└── reports/                         ← Generated HTML compliance reports
```

### Prerequisites

- VS Code with Copilot Chat enabled
- Access to the reviewer workspace
- Agent specification (README or GitHub link) to review

### Step 1: Open the Workspace

```bash
code c:\Repos\Capgemini\experiments\reviewer
```

### Step 2: Open Copilot Chat

In VS Code:
- Press `Ctrl + Shift + I` (or `Cmd + Shift + I` on Mac)
- Or click the Chat icon in the sidebar

### Step 3: Mention the Reviewer Agent

Type `@Reviewer` in the chat input and select it from the dropdown menu.

### Step 4: Start a Review

With the Reviewer agent referenced, type one of these commands:

**Simple:**
```
@Reviewer Review the Flood Risk Agent against DEFRA standards
```

**With context:**
```
@Reviewer I want you to review the "Water Quality Monitoring Agent" for DEFRA compliance. 
Here's the agent specification: [paste content or link]
```

**Providing a link:**
```
@Reviewer Review the agent at: https://github.com/example/water-quality-agent/blob/main/README.md
```

### Step 5: Provide Agent Information

The Reviewer will ask:

> "What is the Agent you want to review?"

Provide one of:
1. **Link to agent documentation** - GitHub README, specification file
2. **Paste agent specification** - Copy/paste your completed `compliant-agent-template.md`
3. **Describe the agent** - Explain what it does, key features, governance approach

### Step 6: Receive Compliance Report

The Reviewer will:
1. ✓ Ask clarifying questions if needed
2. ✓ Analyze against all 5 DEFRA standards
3. ✓ Generate HTML compliance report
4. ✓ Save report to `reports/` directory
5. ✓ Provide final verdict: COMPLIANT / PARTIAL / NON-COMPLIANT

### Example Output

```
DEFRA Compliance Review Complete ✓

Agent: Water Quality Monitoring Agent
Verdict: ✅ COMPLIANT
Compliance Score: 88%

Areas Assessed:
1. System Type Selection - ✓ COMPLIANT
2. Responsible Design Principles - ✓ COMPLIANT  
3. Governance & Oversight - ~ PARTIAL (missing DPIA)
4. Technical & Delivery Guidance - ✓ COMPLIANT
5. Security & Integration - ✓ COMPLIANT

Report saved to: reports/water_quality_agent_20250720_143022.html

Recommendations:
- Complete DPIA for personal location data
- Add post-deployment feedback mechanism
- Document fairness monitoring dashboard

Next Steps: Address recommendations, then submit for follow-up review
```

## Refreshing DEFRA Resource Files

Use this when the source standards documents change and you want to regenerate the markdown files under `.github/resources/`.

### Step 1: Edit the Resource Manifest

Open `.github/resources/resource_sources.json`.

Each entry under `resources` defines one output file and can point to a different repository.

Example:

```json
{
   "name": "ai-checklist",
   "enabled": true,
   "repo": "https://github.com/your-org/your-docs-repo.git",
   "ref": "main",
   "source": "docs/ai-playbook.md",
   "heading": "2.4. AI System Selection Checklists",
   "output": "ai-checklist.md"
}
```

Field meanings:
- `repo` - Git URL or local path to the source repository for this resource
- `ref` - Optional branch, tag, or ref to clone
- `source` - Path to the markdown file inside that repository
- `heading` - Optional heading to extract a single section from the source file
- `output` - Target file name under `.github/resources/`

### Step 2: Validate the Mapping

Run:

```bash
python scripts/update_resources.py --dry-run
```

This checks that each enabled resource can be cloned, the source file exists, and the requested heading can be found.

### Step 3: Regenerate the Files

Run:

```bash
python scripts/update_resources.py
```

The script will rewrite the matching files in `.github/resources/` and add a metadata comment showing the source repo, ref, file, and heading.

## Programmatic Report Generation

Generate a compliance report directly in Python when you do not want to go through Copilot Chat.

```bash
python .github/skills/generate-report/scripts/generate_report.py
```

Or use the reporter class in code:

```python
from scripts.generate_report import DefraComplianceReporter

reporter = DefraComplianceReporter("My Agent")
reporter.add_assessment(
   "System Type Selection",
   "COMPLIANT",
   "Agent correctly selected as AI Agent",
   [{"name": "Autonomous decisions", "status": "COMPLETE"}]
)
reporter.save_report(reporter.generate_html())
```

## Using the Template

### For Your Own Agent

1. **Copy the template:**
   ```
   Copy: .github/templates/compliant-agent-template.md
   To:   .github/templates/YourAgentName.md
   ```

2. **Fill it out** with your agent details
   - All 5 sections (System Type, Responsible Design, Governance, Technical, Additional)
   - Be thorough - details help identify gaps
   - Link to your documentation

3. **Request review:**
   ```
   Review my YourAgentName agent
   ```

4. **Paste content or link:**
   - Paste your completed `compliant-agent-template.md`
   - Or provide GitHub link
   - Or drag-and-drop the file

### Tips for Filling the Template

- ✓ **Be specific** - "We use encryption" vs "TLS 1.3 with AES-256"
- ✓ **Provide evidence** - Link to documents, GitHub repos, dashboards
- ✓ **Show compliance** - Check [x] boxes for completed items
- ✓ **Be honest** - Note gaps or work-in-progress items
- ✓ **Get signatures** - Ensure stakeholders sign off

## The 5 Compliance Areas (TL;DR)

| Area | Key Question | Examples |
|------|---|---|
| **1. System Type** | Did you choose the right tool? | Agent vs Workflow vs RPA vs MAS? Meets 3+ checklist criteria? |
| **2. Responsible Design** | Is it Safe/Effective/Responsible/Explainable/Fair? | Risk assessed? Metrics defined? Owner assigned? Decisions logged? Fair across regions? |
| **3. Governance** | Are roles assigned and controls in place? | Business Owner? DPIA? Oversight protocols? Version control? Feedback loops? |
| **4. Technical** | Is architecture sound and deployment ready? | 4-layer architecture? Testing completed? Secure pipeline? Monitoring in place? Learning loops? |
| **5. Security** | Is it secure and properly integrated? | Role-based access? Data encrypted? Audit logs? DEFRA compliance? |

## Understanding Verdicts

### ✅ COMPLIANT (Score: 80-100%)

Agent meets all DEFRA standards.

**Recommendation:** Ready for deployment

**Action:** 
- Get final approvals
- Deploy to production
- Begin monitoring
- Schedule annual review

### ⚠️ PARTIAL (Score: 60-79%)

Agent meets most standards but has some gaps.

**Recommendation:** Create remediation plan

**Action:**
- Address items marked "MISSING" in report
- Prioritize by risk/effort
- Plan timeline for fixes
- Resubmit after remediation

### ❌ NON-COMPLIANT (Score: <60%)

Agent has critical compliance gaps.

**Recommendation:** Do not deploy until remediated

**Action:**
- Focus on "MISSING" items in Responsible Design and Governance
- Consult Data & Ethics Lead
- Create detailed remediation plan
- Resubmit after significant improvements

## Common Gaps & How to Fix Them

### Gap 1: Missing DPIA

**Problem:** Using personal data without a Data Protection Impact Assessment

**Fix:**
```
1. Identify what personal data you process (location, email, age, etc.)
2. Contact your Data Protection Officer
3. Complete DPIA template
4. Document how data is used and protected
5. Review findings and document mitigations
```

**Timeline:** 1-2 weeks

### Gap 2: No Explainability

**Problem:** Users/stakeholders can't understand why the agent made a decision

**Fix:**
```
1. Log all decision inputs and outputs
2. Generate human-readable decision summaries
3. Show which factors influenced the decision most
4. Provide uncertainty bounds where applicable
5. Make logs accessible to auditors
```

**Timeline:** 2-4 weeks

### Gap 3: Insufficient Testing

**Problem:** Agent not tested on real-world conditions

**Fix:**
```
1. Define test scenarios based on edge cases
2. Test with real data in approved environment
3. Measure accuracy, latency, coverage
4. Include human-in-the-loop testing
5. Document results and lessons learned
```

**Timeline:** 3-6 weeks (depends on data availability)

### Gap 4: No Human Oversight

**Problem:** Agent makes critical decisions without human review

**Fix:**
```
1. Identify critical decision points
2. Design human review workflow
3. Set confidence thresholds (high-confidence: auto, low: escalate)
4. Document approval process and SLAs
5. Implement override capability for operators
```

**Timeline:** 1-3 weeks

### Gap 5: Missing Fairness Testing

**Problem:** Agent outcomes differ across regions or demographics

**Fix:**
```
1. Test accuracy across key demographic groups
2. Test across different regions/geographies
3. Analyze for outcome disparities
4. If found, investigate root causes
5. Implement mitigation (fairness constraints, retraining)
6. Establish ongoing fairness monitoring
```

**Timeline:** 4-8 weeks

## Example Reviews

### Example 1: AI Agent (Compliant)

**Agent:** Invasive Species Detection Agent
```
Review Status: ✅ COMPLIANT (85%)

Area 1: System Type Selection ✓
- Correctly identified as AI Agent
- Meets 4/5 AI Agent criteria
- Good fit for real-time autonomous detection

Area 2: Responsible Design ✓
- Safe: Risk assessment completed, boundaries defined
- Effective: Accuracy 96%, coverage 99%
- Responsible: Owner assigned, DPIA completed
- Explainable: All decisions logged with rationale
- Fair: Testing shows <1% disparity across regions

Area 3: Governance ~ PARTIAL
- All roles assigned ✓
- DPIA completed ✓
- Human oversight protocols ✓
- Version control ✓
- Feedback loop: Not yet operational (planned Q2 2025)

Area 4: Technical ✓
- Architecture sound with 4 layers
- Testing completed on 2 years of data
- Data pipeline secured and documented
- Monitoring dashboards in place
- Post-deployment learning: Plan to implement Q2

Area 5: Security ✓
- Role-based access implemented
- Data encrypted (TLS + AES-256)
- Audit logging configured
- Compliance verified

Verdict: COMPLIANT
Next: Minor improvements to feedback loops, then ready for full deployment
```

### Example 2: Traditional RPA (Non-Compliant)

**Agent:** Data Entry Bot
```
Review Status: ❌ NON-COMPLIANT (35%)

Problem: System was misclassified as "AI Agent" but is actually Traditional RPA

Area 1: System Type Selection ✗
- Incorrectly labeled as AI Agent
- Actually meets RPA criteria: Repetitive, rule-based, UI automation
- Does NOT meet any AI Agent criteria
- Recommendation: Reclassify as RPA and reassess

Area 2: Responsible Design ✗ PARTIAL
- Safe: No risk assessment for data errors
- Effective: No success metrics defined
- Responsible: No owner assigned
- Explainable: No logging of data entry decisions
- Fair: Not applicable for data entry

Area 3: Governance ✗
- No roles assigned
- No DPIA (processes personal data, needs one!)
- No oversight protocols
- No version control of bot scripts

Area 4: Technical ✗
- No architecture documentation
- Minimal testing (only manual QA)
- Data quality validation missing
- No monitoring beyond error logs

Area 5: Security ✗
- No role-based access to bot
- No encryption of credentials
- Audit logging incomplete
- DEFRA compliance unclear

Verdict: NON-COMPLIANT - DO NOT DEPLOY
Critical Issues:
1. Reclassify as RPA (not AI Agent)
2. Complete DPIA for personal data
3. Implement proper governance
4. Add security controls
5. Establish monitoring
```

## Resources

### In This Folder

```
reviewer/
├── QUICKSTART.md                ← This file
├── .github/                     ← All documentation centralized
│   ├── copilot-instructions.md  ← Agent instructions
│   ├── agents/
│   │   └── reviewer.md          ← Reviewer agent (@Reviewer)
│   ├── resources/               ← DEFRA standards
│   │   ├── ai-checklist.md
│   │   ├── right-approach.md
│   │   ├── responsible-design-principles.md
│   │   ├── governance-oversight.md
│   │   ├── technical-delivery-guidance.md
│   │   └── resource_sources.json
│   └── templates/
│       ├── compliant-agent-template.md  ← Fill this in for your agent
│       └── example-compliant-agent.md ← Example (88% compliant)
│
├── scripts/
│   └── update_resources.py      ← Refresh .github/resources from source repos
│
└── reports/                     ← Compliance reports saved here
```

### External Resources

- [DEFRA AI Agents Playbook](https://github.com/DEFRA/defra-ai-agents)
- [UK Government AI Playbook](https://www.gov.uk/government/publications/ai-playbook-for-the-uk-government)
- [UK GDPR Guidance](https://ico.org.uk/)

## Getting Help

### Ask in Copilot Chat

```
What's the difference between an AI Agent and an AI Workflow?
```

```
How do I complete the DPIA section?
```

```
What metrics should I track for my agent?
```

```
How do I implement human oversight for critical decisions?
```

### Contact Support

- **General Questions:** Ask Copilot Chat ("Help with DEFRA compliance")
- **Data Protection:** Contact your Data Protection Officer
- **Governance:** Contact your Governance & Compliance Team
- **Ethics Review:** Contact your Data & Ethics Lead
- **Technical:** Contact your Technical Lead / Architect

## What Happens Next?

### After Review

1. **If COMPLIANT** (80%+)
   - Ready for deployment
   - Schedule annual compliance review
   - Continue monitoring metrics

2. **If PARTIAL** (60-79%)
   - Address gaps identified in report
   - Create remediation plan with timeline
   - Schedule follow-up review (2-4 weeks)

3. **If NON-COMPLIANT** (<60%)
   - DO NOT DEPLOY
   - Address critical gaps first
   - Consult Data & Ethics Lead
   - Plan significant improvements
   - Resubmit after major remediation

### Ongoing Compliance

Even after deployment:

- ✓ Monitor compliance metrics monthly
- ✓ Update team AI register quarterly  
- ✓ Conduct fairness audit annually
- ✓ Schedule third-party review annually
- ✓ Respond to incidents within SLA

## FAQ

**Q: How long does a review take?**
A: 1-2 hours to analyze + generate report. Follow-up reviews 30 minutes.

**Q: Can I update my agent during review?**
A: Yes - resubmit with updates and we'll re-assess.

**Q: What if I disagree with the verdict?**
A: Request escalation to Data & Ethics Lead with justification.

**Q: Is this mandatory?**
A: Yes - all AI agents deployed in DEFRA must comply.

**Q: Can I reuse assessments from other projects?**
A: No - each agent must be individually assessed. Contexts and use cases differ.

---

## Ready to Get Started? 🚀

**In VS Code Copilot Chat:**

1. Type `@` to open agent picker
2. Select **@Reviewer** 
3. Ask:
```
Review [YourAgentName] against DEFRA standards
```

**That's it!** The Reviewer Agent will guide you through the compliance assessment and generate an HTML report.

---

**Need help?** Ask the Reviewer agent:
```
@Reviewer What should I include in the Security section of the template?
```
