# 2.3. Selecting the Right Approach

Note: Any example use cases are to illustrate where AI Agents, Workflows, RPA, or Multi-Agent Systems could be applied within Defra contexts. They are not confirmations

## A. Use AI Agents When:

- The system needs goal-directed behaviour
  - Example: An AI agent that identifies and responds to invasive species outbreaks in near real-time.
- Decisions depend on real-time inputs
  - Example: An agent that adapts irrigation schedules based on weather, soil, and crop status.
- There is uncertainty or changing conditions
  - Example: A flood-response agent that reacts to sensor data and weather alerts.
- The system should adapt and learn over time
  - Example: A livestock monitoring agent that learns normal vs. abnormal behaviour for early disease detection.

## B. Use AI Workflows When:

- Tasks are predictable and repeatable, but not rule-only
  - Example: Processing satellite imagery to identify land cover with human verification.
- You need to orchestrate models or decisions
  - Example: Environmental permit processing workflow using ML risk scoring and policy checks.
- Human-in-the-loop is required
  - Example: Flagging potentially non-compliant fishing reports for review.
- You need full audit trails and transparency
  - Example: Classifying chemical use in farming with documented steps and model outputs.

## C. Use Traditional Automation (RPA) When:

- The task is repetitive, rule-based, and low variability
  - Example: Extracting water quality readings from spreadsheets and pasting them into a legacy system.
- No AI or learning is required
  - Example: Transferring inspection results from email attachments into an internal database.
- Interaction with UI-based systems is necessary
  - Example: A bot that logs into a legacy website and downloads environmental compliance reports daily.
- The aim is to reduce manual data entry or speed up workflows
  - Example: Auto-filing permit renewals from a fixed template.

## D. Use Multi-Agent Systems When:

- The problem involves multiple stakeholders or domains
  - Example: Policy simulation with agents representing biodiversity, flood risk, and agricultural productivity.
- Agents must coordinate or negotiate
  - Example: Coordinated response by different agents to wildfire outbreaks across regions.
- Roles require independent behaviours or goals
  - Example: One agent forecasts pollution spread, another plans cleanup, and another communicates with responders.
