# Supplier Agent Template

Use this template to document your AI Agent for DEFRA Standards Compliance Review.

---

## Agent Overview

**Agent Name**: [Name of the Agent]

**Description**: [Brief description of what the agent does]

**Business Owner**: [Name and role]

**Technical Lead**: [Name and role]

**Status**: [Development/Testing/Production]

---

## 1. System Type & Approach Selection

### Selected System Type
- [ ] AI Agent
- [ ] AI Workflow
- [ ] Traditional RPA
- [ ] Multi-Agent System

### Justification
[Explain why this system type was selected. Reference the appropriate checklist from ai-checklist.md]

**Checklist Items Met**: [List the 3+ items from the appropriate checklist]

---

## 2. Responsible Design Principles

### 2.1 Safe
- [ ] Risk assessment completed
- [ ] Testing plan documented with real-world conditions
- [ ] Safety limits and fallback mechanisms defined
- [ ] Agent action boundaries clearly defined
- [ ] Safe interrupt/override capabilities implemented

**Details**: [Describe your safety measures]

### 2.2 Effective
- [ ] Success metrics defined aligned with policy goals
- [ ] Validation plan through pilots or staged rollouts documented
- [ ] Performance improvement measurements planned

**Details**: [Describe your effectiveness measures and expected improvements]

### 2.3 Responsible
- [ ] Clear owner identified and accountable
- [ ] DPIA completed if personal data is involved
- [ ] Human oversight protocols documented
- [ ] Ethical considerations addressed

**Details**: [Describe governance and oversight approach]

### 2.4 Explainable
- [ ] Decision rationale is interpretable or documented
- [ ] Logging of all decisions and actions in place
- [ ] Clear summaries provided to users and stakeholders

**Details**: [Describe how decisions are explained to users]

### 2.5 Fair
- [ ] Testing for outcome parity across demographics/regions planned
- [ ] Bias mitigation strategies identified
- [ ] Fairness monitoring approach documented

**Details**: [Describe fairness assurance measures]

---

## 3. Governance & Oversight

### Key Roles Assigned
- [ ] Business Owner: [Name]
- [ ] AI Product Lead / Delivery Manager: [Name]
- [ ] Data & Ethics Lead: [Name]
- [ ] Technical Lead / Developer: [Name]
- [ ] Governance / Compliance Team: [Name]

### Required Controls & Artifacts
- [ ] DPIA completed (if applicable): [Link or date]
- [ ] Human Oversight Protocols documented: [Link or attachment]
- [ ] Model & Agent Version Control in place: [System used, e.g., Git]
- [ ] Impact Review & Feedback Loop established: [Description]

### Governance Best Practices
- [ ] AI governance embedded in agile delivery
- [ ] Independent peer review completed
- [ ] System registered in team AI register
- [ ] Accountable owner identified and documented
- [ ] Ethics and legal monitoring plan established

**Governance Details**: [Describe your governance approach]

---

## 4. Technical & Delivery Guidance

### System Architecture

#### Perception (Input)
- **Data Sources**: [APIs, sensors, files, user input, etc.]
- **Data Collection Method**: [How data is collected]
- **Frequency**: [Real-time, batch, triggered]

#### Reasoning (Logic/Model)
- **Model/Rules Approach**: [ML model, rule-based, hybrid]
- **Model Type**: [e.g., LLM, classification model, decision tree]
- **Goals Defined**: [Clear statement of agent goals]

#### Action (Execution)
- **Actions Performed**: [What the agent does - updates systems, sends alerts, triggers APIs]
- **Action Limits**: [Boundaries on what the agent can do]

#### Feedback/Adaptation
- [ ] Learning loop implemented
- [ ] Feedback mechanism established
- [ ] Continuous improvement process in place

**Architecture Details**: [Describe your system architecture]

### Key Delivery Activities

#### 1. Design for Governance from the Start
- [ ] Accountability defined
- [ ] Deployment plan with fail-safes documented
- [ ] Monitoring and oversight points defined

**Details**: [Your governance by design approach]

#### 2. Test Models, Workflows, and Agents Thoroughly
- [ ] Testing plan with real data in approved environments
- [ ] Metrics defined: Accuracy, Latency, False Positive Rate, Impact
- [ ] Human-in-the-loop testing for critical decisions planned

**Details**: [Your testing strategy and results]

#### 3. Secure and Document the Data Pipeline
- [ ] Data quality validation completed
- [ ] Data completeness checks in place
- [ ] Bias assessment completed
- [ ] Defra data standards compliance verified
- [ ] Dataset and model versioning implemented

**Details**: [Your data security and documentation approach]

#### 4. Deploy with Monitoring and Alerting
- [ ] Logging of inputs, outputs, and decisions implemented
- [ ] Alerts configured for failures and threshold breaches
- [ ] Dashboards for live operations established

**Details**: [Your monitoring and alerting setup]

#### 5. Plan for Post-Deployment Learning or Iteration
- [ ] Review cycle schedule established
- [ ] User feedback mechanism implemented
- [ ] Change log maintained

**Details**: [Your post-deployment improvement plan]

### Metrics to Track

| Metric Category | Metrics | Current/Planned Values |
|---|---|---|
| Performance | Accuracy, Latency, Coverage, Error Rate | [Values] |
| Impact | Time saved, Decisions accelerated, Consistency | [Values] |
| Fairness | Outcome parity across demographics/regions | [Values] |
| Transparency | % decisions logged, ATRS completion | [Values] |
| Safety | Errors detected, Response time to anomalies | [Values] |

### Security & Access Control
- [ ] Role-based access implemented
- [ ] Sensitive data encryption in place
- [ ] Audit logging configured
- [ ] DEFRA and CDDO guidance followed

**Details**: [Your security approach]

### Tool Selection
- **Primary Tools**: [LangGraph, Azure AI Foundry, Claude, AutoGen, etc.]
- **Integration Approach**: [APIs, webhooks, direct integration]
- **Data Pipeline Tools**: [Azure Data Factory, Pandas, etc.]

---

## 5. Additional Information

### Links & Documentation
- Repository URL: [GitHub/GitLab link]
- Documentation: [Link to full documentation]
- Architecture Diagram: [Link or attachment]
- API Documentation: [If applicable]

### Deployment Information
- **Environment**: [Development/Staging/Production]
- **Deployment Date**: [Date or planned date]
- **Update Frequency**: [How often is the agent updated?]

### Known Issues or Gaps
[List any known compliance gaps or areas for improvement]

### Support & Escalation
- **Support Contact**: [Email/Slack]
- **Escalation Path**: [How to escalate issues]

---

## Sign-Off

By submitting this template, the team confirms that the agent has been designed and will be deployed in compliance with DEFRA Standards.

**Business Owner Signature**: _________________ **Date**: _________

**Technical Lead Signature**: _________________ **Date**: _________

**Data & Ethics Lead Signature**: _________________ **Date**: _________
