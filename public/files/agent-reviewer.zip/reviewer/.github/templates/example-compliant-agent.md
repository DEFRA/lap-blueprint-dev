# Example Supplier Agent - Flood Risk Detection Agent

This is an example completed supplier agent template showing how delivery teams should document their agents for DEFRA compliance review.

---

## Agent Overview

**Agent Name**: Flood Risk Detection Agent

**Description**: An AI agent that monitors real-time weather data, water level sensors, and topographic information to detect imminent flood risks. The agent analyzes conditions in near-real-time and triggers mitigation actions including alerts to relevant stakeholders, automated deployment of barriers, and resource allocation to affected regions.

**Business Owner**: Sarah Mitchell, Head of Environmental Monitoring

**Technical Lead**: James Park, Senior AI Engineer

**Status**: Production

---

## 1. System Type & Approach Selection

### Selected System Type
- [x] AI Agent
- [ ] AI Workflow
- [ ] Traditional RPA
- [ ] Multi-Agent System

### Justification

The Flood Risk Detection Agent was correctly selected as an AI Agent because it meets 5/5 criteria from the AI Agent checklist:

1. **Autonomous, goal-driven decisions** ✓ - The agent autonomously decides when to issue flood warnings and trigger mitigation actions based on risk assessment
2. **Dynamic, unpredictable environment** ✓ - Weather patterns and water levels change in real-time; the agent must adapt to rapidly changing conditions
3. **Real-time inputs** ✓ - Continuously monitors sensor feeds from 250+ monitoring stations across the region
4. **Adaptive and learning capability** ✓ - The agent learns from historical flood patterns to improve predictions over time
5. **Low-latency decision-making** ✓ - Decisions must be made within seconds to allow for timely warnings and evacuation

**Decision:** AI Agent is appropriate because the system requires autonomous, real-time, adaptive decision-making in a highly dynamic environment.

---

## 2. Responsible Design Principles

### 2.1 Safe
- [x] Risk assessment completed
- [x] Testing plan documented with real-world conditions
- [x] Safety limits and fallback mechanisms defined
- [x] Agent action boundaries clearly defined
- [x] Safe interrupt/override capabilities implemented

**Details**: 

We conducted a comprehensive safety risk assessment identifying three main risk categories:
1. **False Negatives** (missed floods) - Could lead to loss of life
2. **False Positives** (unnecessary warnings) - Could cause evacuation fatigue and reduced compliance
3. **System Failures** - Could leave regions without warning capability

**Mitigations:**
- False Negative Risk: Accuracy threshold set at 95% for alerts; any predictions below 92% require human review
- False Positive Risk: Models tested on historical data; flagged alerts reviewed by meteorologists
- System Failure: Manual override capability always available; regional meteorologists can manually trigger warnings

**Testing:** Agent tested on 10 years of historical weather data and actual flood events. Real-world validation completed across 5 flood seasons (2020-2024) with 99.2% alert accuracy.

**Safety Limits:** 
- Agent cannot directly order evacuations (requires human authorization)
- Maximum warning lead time: 72 hours (beyond which accuracy degrades)
- Emergency override available at all times for duty officers

### 2.2 Effective
- [x] Success metrics defined aligned with policy goals
- [x] Validation plan through pilots or staged rollouts documented
- [x] Performance improvement measurements planned

**Details**:

**Success Metrics Aligned with Defra Policy:**
- Early Warning Effectiveness: 90% of floods detected with 6+ hours warning
- Stakeholder Notification: 100% of at-risk areas receive alerts within 10 minutes
- Mitigation Deployment: Automated systems activated within 5 minutes of warning
- Decision Accuracy: False positive rate < 5%, False negative rate < 2%

**Validation Approach:**
- Phase 1 (Pilots, 2022): 5 pilot regions with 100% human oversight
- Phase 2 (2023): 20 regions with 80% automated, 20% human oversight
- Phase 3 (2024-Present): Full deployment with continuous monitoring
- Current: 47 regions with 95% automated decision-making

**Measured Improvements:**
- Response time improved from 4-6 hours (manual) to 10-30 minutes (automated)
- Coverage improved from 73% to 98% of at-risk areas
- Cost savings: £12.3M annually through optimized resource deployment

### 2.3 Responsible
- [x] Clear owner identified and accountable
- [x] DPIA completed if personal data is involved
- [x] Human oversight protocols documented
- [x] Ethical considerations addressed

**Details**:

**Accountability:**
- Business Owner: Sarah Mitchell (sarah.mitchell@defra.gov.uk)
- Responsible for overall effectiveness and stakeholder communication
- Monthly performance reviews and quarterly governance meetings

**Data Protection:**
- DPIA Completed: Yes (Document: dpia-flood-agent-v2.1.pdf, dated 2024-01-15)
- Personal Data Processed: Location data (addresses of at-risk properties), email addresses for notifications
- Justification: Necessary for flood warnings; lawful basis is legal obligation under Flood and Water Management Act 2010
- Data Retention: Retained for 10 years for pattern analysis; anonymized beyond 2 years

**Human Oversight Protocols:**
- Critical Alerts (>75% risk): Reviewed by senior meteorologist before public release
- Weather Anomalies: Any unusual weather patterns automatically escalated for review
- Regional Variations: Local authorities can request manual review of predictions
- Override Capability: Always available; 5-minute response SLA for override requests

**Ethical Considerations Addressed:**
- **Fairness:** Agent applies same risk assessment criteria across all demographics; no disparity in warning times found (ATRS analysis completed)
- **Transparency:** Users can request explanation of why their area received an alert
- **Accessibility:** Alerts provided in 12 languages; multiple notification channels (SMS, email, app, radio)

### 2.4 Explainable
- [x] Decision rationale is interpretable or documented
- [x] Logging of all decisions and actions in place
- [x] Clear summaries provided to users and stakeholders

**Details**:

**Interpretability:**
- Primary Models: Interpretable ensemble of XGBoost (weather patterns) and LSTM (temporal sequences)
- Feature Importance: Published monthly showing which factors most influence predictions
- Decision Justification: For each alert, generated summary: "Flood risk increased from 12% to 78% due to: sustained rainfall (+40%), upstream water level rise (+25%), local drainage capacity (-8%)"

**Decision Logging:**
- All agent decisions logged with: timestamp, input data used, confidence score, action taken
- Logs stored in audit-compliant database with immutable timestamps
- Accessible to stakeholders for post-event analysis
- 100% of floods (false positive/negative) analyzed within 48 hours

**User Communication:**
- Public alerts include: risk percentage, expected impact, recommended actions, uncertainty bounds
- Example: "FLOOD ALERT: Essex Region - 85% confidence (uncertainty range: 78-91%). Expected flooding in low-lying areas. Evacuation recommended for riverside properties. Lead time: 14 hours."

### 2.5 Fair
- [x] Testing for outcome parity across demographics/regions planned
- [x] Bias mitigation strategies identified
- [x] Fairness monitoring approach documented

**Details**:

**Fairness Testing Completed:**
- Geographic Equity: Alert accuracy tested across urban (98.1%), rural (97.3%), and coastal (97.8%) regions - no significant disparity
- Demographic Parity: Alert timing and quality analyzed across deprivation quintiles - no correlation found between socioeconomic status and alert quality
- Infrastructure Differences: Separate models trained for different drainage types; accuracy maintained across all variations

**Bias Mitigation:**
- Training Data Bias: Historical flood data rebalanced to prevent over-representation of recent/frequent locations
- Seasonal Bias: Separate models for winter/summer flood patterns
- Model Drift Detection: Monthly retraining with fairness constraints; alerts if parity drops below 97%

**Fairness Monitoring (Ongoing):**
- Quarterly fairness audits across all dimensions
- Dashboard tracking: Alert accuracy by region, demographics, infrastructure type
- Escalation trigger: If any group shows >2% accuracy disparity, automatic investigation and model retraining

---

## 3. Governance & Oversight

### Key Roles Assigned
- [x] Business Owner: Sarah Mitchell, Head of Environmental Monitoring (sarah.mitchell@defra.gov.uk)
- [x] AI Product Lead / Delivery Manager: David Chen, Programme Manager (david.chen@defra.gov.uk)
- [x] Data & Ethics Lead: Dr. Emma Rodriguez, Data Ethics Officer (emma.rodriguez@defra.gov.uk)
- [x] Technical Lead / Developer: James Park, Senior AI Engineer (james.park@defra.gov.uk)
- [x] Governance / Compliance Team: Legal & Compliance Office, CDDO representation

### Required Controls & Artifacts
- [x] DPIA completed: Yes - dpia-flood-agent-v2.1.pdf (Updated Jan 2024, Due: Jan 2025)
- [x] Human Oversight Protocols documented: flood-agent-oversight-protocol-v3.md
- [x] Model & Agent Version Control in place: Git repository (private GitHub Enterprise), models in DVC
- [x] Impact Review & Feedback Loop established: Quarterly stakeholder reviews, monthly performance dashboards, user feedback portal

### Governance Best Practices
- [x] AI governance embedded in agile delivery - Governance criteria reviewed in sprint planning and DoD
- [x] Independent peer review completed - Annual third-party audit by external AI experts (last: October 2024)
- [x] System registered in team AI register - Registry ID: DEFRA-FLOOD-001 (Status: Active, Last Updated: Jan 2025)
- [x] Accountable owner identified and documented - Sarah Mitchell is accountable and has signed governance agreement
- [x] Ethics and legal monitoring plan established - Monthly ethics reviews, continuous legal compliance monitoring

**Governance Details**:

The agent is governed through a multi-layered approach:

1. **Strategic Governance** (Business Owner level)
   - Quarterly steering committee meetings
   - Annual ROI and impact reviews
   - Stakeholder feedback integration

2. **Operational Governance** (Product/Technical Lead level)
   - Weekly performance monitoring dashboards
   - Monthly model retraining and bias audits
   - Sprint-based capability enhancements

3. **Compliance Governance** (Legal/Ethics/Compliance level)
   - Continuous GDPR compliance monitoring
   - Quarterly fairness audits
   - Annual independent third-party assessment

4. **Technical Governance** (Developer level)
   - Code reviews for all changes
   - Automated testing on 100% of code
   - Model validation before every deployment

---

## 4. Technical & Delivery Guidance

### System Architecture

#### Perception (Input)
- **Data Sources**: 
  - 250+ water level sensors (real-time, every 15 minutes)
  - 100+ weather stations (temperature, rainfall, pressure)
  - Satellite imagery (every 30 minutes during risk periods)
  - Drainage system telemetry
  - Historical flood records (10 years)

- **Data Collection Method**: 
  - Real-time API feeds from Environment Agency sensor network
  - Automated ETL pipeline processing 50GB daily
  - Data quality checks at ingestion with 99.8% uptime

- **Frequency**: Real-time continuous monitoring with predictions every 30 minutes

#### Reasoning (Logic/Model)
- **Model/Rules Approach**: Hybrid ensemble combining ML models with domain expert rules

- **Model Types**:
  - Primary: XGBoost ensemble (weather/sensor interpretation) - 91% feature importance documented
  - Secondary: LSTM neural network (temporal pattern detection) - Captures seasonal and multi-day trends
  - Tertiary: Physics-based flow models (hydrological simulation) - Expert validation layer

- **Goals Defined**: 
  - Primary Goal: "Maximize lead time for flood warning while maintaining >95% accuracy"
  - Secondary Goals: "Minimize false positives to maintain public trust", "Ensure equitable coverage across all regions"
  - Constraint: "Always prioritize loss-of-life prevention over cost optimization"

#### Action (Execution)
- **Actions Performed**:
  1. Issue public alerts (SMS, email, app notification)
  2. Trigger automated mitigation (deploy barriers, activate pumps)
  3. Notify emergency services (fire, police, NHS)
  4. Activate regional resource deployment
  5. Update public website and media feeds
  6. Log decision and outcome for audit

- **Action Limits**: 
  - Cannot order evacuations (requires human authorized sign-off)
  - Cannot control water discharge (environmental agency retains control)
  - Cannot modify traffic signals or infrastructure
  - Maximum alert lead time: 72 hours

#### Feedback/Adaptation
- [x] Learning loop implemented - Monthly retraining on new flood events
- [x] Feedback mechanism established - Post-event root cause analysis conducted within 48 hours
- [x] Continuous improvement process in place - Quarterly model retraining with fairness constraints

**Feedback Process:**
- Automatic: Model retrains monthly on latest data with updated constraints
- Post-Event: Within 48 hours of any significant event, team conducts analysis
- User Feedback: Regional authorities can submit feedback via portal; monthly review
- Performance Trends: Dashboard tracks accuracy decay; retraining triggered at 95% threshold

**Architecture Details**:

System built on Kubernetes with:
- Model serving via Seldon Core (real-time inference, <2 second latency)
- Data processing with Apache Spark (batch retraining)
- Messaging via Kafka (real-time alerts)
- Monitoring with Prometheus/Grafana
- Audit logging with ELK stack

### Key Delivery Activities

#### 1. Design for Governance from the Start
- [x] Accountability defined - Business Owner: Sarah Mitchell
- [x] Deployment plan with fail-safes documented - flood-agent-deployment-v2.md
- [x] Monitoring and oversight points defined - 15 monitoring dashboards, 8 escalation points

**Details**: From day 1 of development, governance requirements were embedded:
- Architecture designed for human oversight at critical points
- Audit logging implemented from prototype stage
- Model validation checkpoints defined before development began

#### 2. Test Models, Workflows, and Agents Thoroughly
- [x] Testing plan with real data in approved environments - Completed 5 flood seasons (2020-2024)
- [x] Metrics defined: Accuracy (99.2%), Latency (<2s), False Positive Rate (1.3%), Impact (£12.3M saved)
- [x] Human-in-the-loop testing for critical decisions planned - 100% of alerts reviewed in pilot phase

**Testing Results**:
- Tested on 10 years of historical data + 5 real flood seasons
- Model accuracy: 99.2% on validation set
- False positive rate: 1.3% (target: <2%)
- Response latency: 0.8 seconds (target: <2 seconds)
- Coverage: 98% of at-risk areas

#### 3. Secure and Document the Data Pipeline
- [x] Data quality validation completed - Automated quality checks on 100% of ingested data
- [x] Data completeness checks in place - Alert if any sensor missing >4 hours; failover to adjacent sensors
- [x] Bias assessment completed - Fairness audit shows <0.5% disparity across regions
- [x] Defra data standards compliance verified - Follows DEFRA Data Standards v3.2
- [x] Dataset and model versioning implemented - Git + DVC versioning, immutable artifact storage

**Data Security**:
- Encryption: TLS 1.3 in transit, AES-256 at rest
- Access Control: Role-based (5 access levels), MFA required
- Retention: Raw data 90 days, anonymized patterns 10 years
- Audit Trail: Complete audit log of all data access

#### 4. Deploy with Monitoring and Alerting
- [x] Logging of inputs, outputs, and decisions implemented - All decisions logged to audit database
- [x] Alerts configured for failures and threshold breaches - 8 auto-escalation channels
- [x] Dashboards for live operations established - 5 operational dashboards, real-time KPI tracking

**Monitoring Implementation**:
- **Performance Dashboard**: Accuracy, latency, coverage metrics updated every 5 minutes
- **Anomaly Dashboard**: Alerts on unusual patterns, model drift detection
- **Operational Dashboard**: Current active warnings, resource deployment status
- **Compliance Dashboard**: Fairness metrics, access logs, audit trail
- **Business Dashboard**: ROI, stakeholder satisfaction, incident response times

**Alerting:**
- Critical: Model accuracy drops below 95% → Immediate escalation
- High: Any region accuracy drops below 97% → 15-min investigation
- Medium: Response latency exceeds 5 seconds → Technical review
- Low: Unusual weather patterns detected → Meteorologist review

#### 5. Plan for Post-Deployment Learning or Iteration
- [x] Review cycle schedule established - Monthly technical review, quarterly steering committee
- [x] User feedback mechanism implemented - Feedback portal, post-event surveys
- [x] Change log maintained - Git commits, deployment log, model changelog

**Post-Deployment Iteration Process**:
- **Monthly**: Performance analysis, retraining with new data
- **Quarterly**: Fairness audit, user feedback review, steering committee
- **Annually**: Third-party assessment, DPIA review, strategy update

**Change Management:**
- All changes tracked in JIRA + Git
- Model changes tagged with evaluation results
- Deployment log maintains history of all versions
- Rollback capability for any change within 24 hours

### Metrics to Track

| Metric Category | Metrics | Current Value | Target |
|---|---|---|---|
| Performance | Accuracy | 99.2% | >95% |
| | Latency | 0.8s | <2s |
| | Coverage | 98% | >95% |
| | Error Rate | 0.8% | <2% |
| Impact | Time Saved | 4-6 hours/event | N/A |
| | Decisions Accelerated | 100% automated | N/A |
| | Consistency | 98.5% inter-rater | >95% |
| Fairness | Outcome Parity | 0.5% max disparity | <1% |
| | Regional Equity | 97.8-98.1% | No disparity |
| | Demographic Parity | <0.2% skew | No skew |
| Transparency | Decisions Logged | 100% | 100% |
| | ATRS Completed | Yes | Yes |
| | Explainability Rate | 100% | 100% |
| Safety | Errors Detected | 48 hour detection | <48 hours |
| | Response Time | 4 hours | <4 hours |
| | System Uptime | 99.8% | >99% |

### Security & Access Control
- [x] Role-based access implemented - 5 access levels defined (Admin, Senior Operator, Operator, Viewer, Public API)
- [x] Sensitive data encryption in place - TLS 1.3 + AES-256
- [x] Audit logging configured - Complete audit trail stored in ELK
- [x] DEFRA and CDDO guidance followed - Aligned with CDDO Cloud Security Principles

**Security Measures**:
- **Authentication**: SSO via DEFRA Active Directory + MFA
- **Authorization**: Role-based access control (RBAC) with least privilege
- **Encryption**: End-to-end encryption for all data flows
- **Audit**: All actions logged with user, timestamp, data accessed
- **Compliance**: Annual security audit, penetration testing, DPIA review

### Tool Selection
- **Primary Tools**: 
  - Model Development: Python (scikit-learn, TensorFlow, XGBoost)
  - Orchestration: Apache Airflow
  - Serving: Seldon Core on Kubernetes
  - Database: PostgreSQL + Redis
  
- **Integration Approach**: 
  - RESTful APIs for sensor data ingestion
  - Pub/Sub via Kafka for real-time alerts
  - Database APIs for historical data
  
- **Data Pipeline Tools**: 
  - Apache Spark for ETL
  - Pandas for data transformation
  - Great Expectations for data validation

---

## 5. Additional Information

### Links & Documentation
- Repository URL: https://github.com/DEFRA/flood-risk-agent (private)
- Full Documentation: https://defra-confluence.atlassian.net/wiki/spaces/FLOOD/overview
- Architecture Diagram: [Included as architecture.png in repo]
- API Documentation: https://api-docs.defra.gov.uk/flood-agent/v2

### Deployment Information
- **Environment**: Production (47 regions across England)
- **Deployment Date**: 2024-03-15 (full rollout)
- **Update Frequency**: Continuous deployment with 2-week sprint cycles

### Known Issues or Gaps
1. **Minor Gap**: Coastal flood modeling less accurate than inland (97.1% vs 98.8%)
   - Status: Being addressed with additional tidal data integration
   - Timeline: Q2 2025

2. **Documentation Gap**: User-facing explanation of uncertainty bounds could be improved
   - Status: In backlog for Q3 2025
   - Impact: Low (current system meets requirements)

### Support & Escalation
- **Support Contact**: flood-agent-team@defra.gov.uk
- **Escalation Path**: 
  - L1: Technical support team (2-hour SLA)
  - L2: Engineering team (4-hour SLA)
  - L3: Business owner (critical issues, 1-hour SLA)

---

## Sign-Off

By submitting this template, the team confirms that the Flood Risk Detection Agent has been designed and is being deployed in compliance with DEFRA Standards.

**Business Owner Signature**: Sarah Mitchell **Date**: 2025-01-20

**Technical Lead Signature**: James Park **Date**: 2025-01-20

**Data & Ethics Lead Signature**: Dr. Emma Rodriguez **Date**: 2025-01-15
