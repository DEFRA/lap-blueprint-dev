# DEFRA AI Standards - Workspace Instructions

This workspace contains agents and tools for reviewing AI systems against DEFRA standards.

## Workspace Structure

```
.github/
├── copilot-instructions.md       # This file — workspace-level context
├── agents/
│   └── reviewer.md               # @Reviewer — DEFRA compliance review agent
├── skills/
│   └── generate-report/          # Skill: generate HTML compliance report
│       ├── generate-report.md
│       └── scripts/
│           └── generate_report.py
├── resources/                    # DEFRA standards reference documents
└── templates/                    # Submission templates and examples

scripts/
└── update_resources.py           # Refresh .github/resources from source repositories

reports/                          # Generated compliance reports (HTML)
```

## Available Agents

| Agent | Invoke | Purpose |
|-------|--------|---------|
| Reviewer | `@Reviewer` | Assess an AI agent against DEFRA standards and generate an HTML compliance report |

To add a new agent, create a `.md` file in `.github/agents/` with a YAML frontmatter block (`name`, `description`, `skills`, `tools`).

## Available Skills

| Skill | File | Purpose |
|-------|------|---------|
| generate-report | `.github/skills/generate-report/generate-report.md` | Run `.github/skills/generate-report/scripts/generate_report.py` to produce an HTML compliance report |

## Standards Reference

All DEFRA standards documentation lives in `.github/resources/`. Agents and skills should reference these files directly rather than duplicating content.
