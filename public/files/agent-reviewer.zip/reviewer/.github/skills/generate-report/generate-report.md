# Skill: Generate DEFRA Compliance HTML Report

## Purpose

Use the `.github/skills/generate-report/scripts/generate_report.py` script to produce a colour-coded, interactive HTML compliance report after completing a DEFRA standards assessment. Always invoke this skill at the end of every review to generate and save the report.

## When to Use

Invoke this skill after you have assessed an agent against all 5 DEFRA compliance areas and collected the status (`COMPLIANT`, `PARTIAL`, or `NON-COMPLIANT`) and checklist items for each area.

## How to Use

### 1. Collect Assessment Data

For each of the 5 compliance areas, gather:
- **area** (string) – the area name
- **status** – `COMPLIANT`, `PARTIAL`, or `NON-COMPLIANT`
- **details** – a one-paragraph narrative of your assessment
- **items** – a list of individual checklist items, each with:
  - `name` (string)
  - `description` (string, optional)
  - `status` – `COMPLETE` or `MISSING`

### 2. Run the Report Generator

```python
import sys
sys.path.insert(0, '.github/skills/generate-report/scripts')
from generate_report import DefraComplianceReporter

reporter = DefraComplianceReporter("<Agent Name>")

reporter.add_assessment(
    "System Type Selection",
    "COMPLIANT",          # COMPLIANT | PARTIAL | NON-COMPLIANT
    "Narrative details...",
    [
        {"name": "Autonomous goal-driven decisions", "description": "...", "status": "COMPLETE"},
        {"name": "Real-time inputs",                 "description": "...", "status": "COMPLETE"},
        # ... more items
    ]
)

# Repeat add_assessment() for each of the 5 areas:
# - "System Type Selection"
# - "Responsible Design Principles"
# - "Governance & Oversight"
# - "Technical & Delivery Guidance"
# - "Security & Integration"

filepath = reporter.save_report()
print(f"Report saved to: {filepath}")
```

### 3. Report Output

The saved HTML report includes:
- **Overall compliance percentage** – large headline score (e.g. `60%`)
- **Top-level progress bar** – coloured bar spanning the full width
- **Area breakdown** – for each of the 5 areas:
  - Status badge (`COMPLIANT` / `PARTIAL` / `NON-COMPLIANT`)
  - Per-area progress bar showing items complete (e.g. `3 of 5 items · 60%`)
  - Full checklist with green ticks and red crosses
- **Verdict summary** – `COMPLIANT` / `PARTIAL` / `NON-COMPLIANT` with remediation message

Reports are saved to `reports/<agent_name>_<YYYYMMDD>_<HHMMSS>.html`.

## Status Mapping

| Area verdict    | Meaning                                  |
|-----------------|------------------------------------------|
| `COMPLIANT`     | All or most items complete               |
| `PARTIAL`       | Some items missing, requires action plan |
| `NON-COMPLIANT` | Critical items missing, do not deploy    |

| Item status | Meaning              |
|-------------|----------------------|
| `COMPLETE`  | Item verified / done |
| `MISSING`   | Item not documented  |

## Scoring

```
Overall score = (number of COMPLIANT areas / 5) × 100%

80–100% → COMPLIANT      – ready for deployment
60–79%  → PARTIAL        – acceptable with action plan
<60%    → NON-COMPLIANT  – do not deploy
```

## File Location

```
.github/skills/generate-report/
├── generate-report.md              ← this skill file
└── scripts/
    └── generate_report.py          ← report generator

reports/                            ← HTML output directory (workspace root)
```
