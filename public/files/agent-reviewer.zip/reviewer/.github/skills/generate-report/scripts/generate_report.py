#!/usr/bin/env python3
"""
DEFRA Reviewer Agent - HTML Compliance Report Generator

Generates an HTML dashboard showing AI Agent compliance against DEFRA standards.
"""

import json
import datetime
from pathlib import Path
from typing import Dict, List, Tuple

class DefraComplianceReporter:
    """Generate HTML compliance reports for AI agents."""
    
    def __init__(self, agent_name: str, report_dir: str = "reports"):
        self.agent_name = agent_name
        self.report_dir = Path(report_dir)
        self.report_dir.mkdir(exist_ok=True)
        self.timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.assessment = {
            "agent_name": agent_name,
            "timestamp": datetime.datetime.now().isoformat(),
            "areas": {}
        }
        self.recommendations = []
    
    def add_assessment(self, area: str, status: str, details: str, items: List[Dict]):
        """
        Add assessment for a compliance area.
        
        Args:
            area: Compliance area (e.g., "System Type Selection")
            status: Initial status (COMPLIANT, PARTIAL, or NON-COMPLIANT) - will be recalculated based on items
            details: Description of the assessment
            items: List of checked items with status
        """
        # Recalculate status based on item completion
        total_items = len(items)
        complete_items = sum(1 for i in items if i.get("status") == "COMPLETE")
        item_completion_pct = (complete_items / total_items * 100) if total_items > 0 else 0
        
        # Determine status based on item completion
        if item_completion_pct == 0:
            calculated_status = "NON-COMPLIANT"
        elif item_completion_pct == 100:
            calculated_status = "COMPLIANT"
        else:
            calculated_status = "PARTIAL"
        
        self.assessment["areas"][area] = {
            "status": calculated_status,
            "details": details,
            "items": items
        }
    
    def add_recommendation(self, priority: int, title: str, description: str):
        """
        Add a remediation recommendation.
        
        Args:
            priority: Priority order (1 = highest)
            title: Short title
            description: Detailed recommendation
        """
        self.recommendations.append({
            "priority": priority,
            "title": title,
            "description": description
        })
    
    def calculate_overall_verdict(self) -> Tuple[str, float]:
        """Calculate overall compliance verdict and score.
        
        Score is based on item-level completion across all areas, reflecting actual progress.
        Verdict is based on area-level compliance status.
        """
        if not self.assessment["areas"]:
            return "UNKNOWN", 0.0
        
        areas = self.assessment["areas"]
        
        # Calculate verdict based on area-level compliance
        compliant_count = sum(1 for a in areas.values() if a["status"] == "COMPLIANT")
        total_areas = len(areas)
        
        if compliant_count == total_areas:
            verdict = "COMPLIANT"
        elif compliant_count >= total_areas * 0.6:
            verdict = "PARTIAL"
        else:
            verdict = "NON-COMPLIANT"
        
        # Calculate score based on item-level completion (shows actual progress)
        total_items = 0
        complete_items = 0
        for area_data in areas.values():
            items = area_data.get("items", [])
            total_items += len(items)
            complete_items += sum(1 for i in items if i.get("status") == "COMPLETE")
        
        score = (complete_items / total_items * 100) if total_items > 0 else 0.0
        
        return verdict, score
    
    def get_status_color(self, status: str) -> str:
        """Get color code for status."""
        colors = {
            "COMPLIANT": "#28a745",
            "PARTIAL": "#ffc107",
            "NON-COMPLIANT": "#dc3545",
            "COMPLETE": "#28a745",
            "MISSING": "#dc3545"
        }
        return colors.get(status, "#6c757d")
    
    def get_status_icon(self, status: str) -> str:
        """Get icon/emoji for status."""
        icons = {
            "COMPLIANT": "✓",
            "PARTIAL": "~",
            "NON-COMPLIANT": "✗",
            "COMPLETE": "✓",
            "MISSING": "✗"
        }
        return icons.get(status, "?")
    
    def _generate_recommendations_html(self) -> str:
        """Generate HTML for remediation recommendations."""
        if not self.recommendations:
            return ""
        
        sorted_recs = sorted(self.recommendations, key=lambda x: x["priority"])
        items_html = ""
        for rec in sorted_recs:
            items_html += f"<li><strong>{rec['title']}</strong>: {rec['description']}</li>\n"
        
        return f"""
            <div class="recommendations">
                <h3>🔧 Recommended Remediation (Priority Order)</h3>
                <ol>
                    {items_html}
                </ol>
            </div>
        """
    
    def _generate_items_html(self, items: List[Dict]) -> str:
        """Generate HTML for items in an area."""
        html = ""
        for item in items:
            status = item.get("status", "MISSING")
            status_class = "complete" if status == "COMPLETE" else "missing"
            icon = self.get_status_icon(status)
            description_html = ""
            if item.get("description"):
                description_html = f"<p>{item.get('description', '')}</p>"
            
            html += f"""
            <li class="{status_class}">
                <div class="item-icon {status_class}">{icon}</div>
                <div class="item-text">
                    <strong>{item.get('name', 'Item')}</strong>
                    {description_html}
                </div>
            </li>
"""
        return html
    
    def _generate_areas_html(self) -> str:
        """Generate HTML for assessment areas."""
        html = ""
        for area, data in self.assessment["areas"].items():
            status = data["status"]
            color = self.get_status_color(status)
            icon = self.get_status_icon(status)

            items = data.get("items", [])
            total_items = len(items)
            complete_items = sum(1 for i in items if i.get("status") == "COMPLETE")
            item_pct = int((complete_items / total_items) * 100) if total_items > 0 else 0

            items_html = self._generate_items_html(items)

            html += f"""
    <div class="area-section">
        <div class="area-header">
            <div class="area-icon" style="background: {color}20; color: {color};">
                {icon}
            </div>
            <div class="area-title">
                <h2>{area}</h2>
                <div class="area-progress-bar">
                    <div class="area-progress-fill" style="width: {item_pct}%; background: {color};"></div>
                </div>
                <div class="area-progress-label">
                    <span>{complete_items} of {total_items} items complete</span>
                    <span class="area-progress-pct" style="color: {color};">{item_pct}%</span>
                </div>
            </div>
            <div class="area-status" style="background: {color};">
                {status}
            </div>
        </div>
        <div class="area-details">
            {data.get('details', '')}
        </div>
        <ul class="items-list">
            {items_html}
        </ul>
    </div>
"""
        return html
    
    def _generate_summary_html(self, verdict: str, score: float, color: str) -> str:
        """Generate summary verdict box HTML."""
        areas = self.assessment["areas"]
        total_areas = len(areas)
        compliant_count = sum(1 for a in areas.values() if a["status"] == "COMPLIANT")
        partial_count = sum(1 for a in areas.values() if a["status"] == "PARTIAL")
        non_compliant_count = sum(1 for a in areas.values() if a["status"] == "NON-COMPLIANT")

        score_int = int(score)
        message = (
            'Ready for deployment with minor improvements.' if verdict == 'COMPLIANT'
            else 'Requires remediation before deployment.' if verdict == 'NON-COMPLIANT'
            else 'Acceptable with a documented action plan.'
        )

        return f"""
        <div class="verdict-box">
            <div class="verdict-status">{verdict}</div>
            <div class="verdict-score" style="font-size: 2.5em; font-weight: 900; letter-spacing: -1px;">
                {score_int}%
            </div>
            <div style="font-size: 1em; opacity: 0.85; margin-bottom: 12px;">Overall Compliance Score</div>
            <div class="progress-bar">
                <div class="progress-fill" style="width: {score_int}%;"></div>
                <div class="progress-bar-text">{score_int}%</div>
            </div>
            <div style="margin-top: 14px; font-size: 0.95em; opacity: 0.9;">
                {compliant_count} compliant &nbsp;·&nbsp; {partial_count} partial &nbsp;·&nbsp; {non_compliant_count} non-compliant
                &nbsp;&nbsp;|&nbsp;&nbsp; {total_areas} areas assessed
            </div>
            <p style="margin-top: 12px; opacity: 0.95;">{message}</p>
        </div>
"""
    
    def generate_html(self) -> str:
        """Generate complete HTML report."""
        verdict, score = self.calculate_overall_verdict()
        verdict_color = self.get_status_color(verdict)
        
        areas_html = self._generate_areas_html()
        summary_html = self._generate_summary_html(verdict, score, verdict_color)
        recommendations_html = self._generate_recommendations_html()
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEFRA Compliance Review - {self.agent_name}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.5em;
            margin-bottom: 10px;
        }}
        
        .header p {{
            font-size: 1.1em;
            opacity: 0.9;
        }}
        
        .timestamp {{
            font-size: 0.85em;
            opacity: 0.8;
            margin-top: 10px;
        }}
        
        .verdict-box {{
            background: {verdict_color};
            color: white;
            padding: 30px;
            text-align: center;
            margin: 30px;
            border-radius: 8px;
        }}
        
        .verdict-status {{
            font-size: 2em;
            font-weight: bold;
            margin-bottom: 10px;
        }}
        
        .verdict-score {{
            font-size: 1.5em;
            margin-bottom: 5px;
        }}
        
        .progress-bar {{
            width: 100%;
            height: 30px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 15px;
            overflow: hidden;
            margin-top: 15px;
            position: relative;
        }}
        
        .progress-fill {{
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            width: {score}%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: {verdict_color};
            font-weight: bold;
            transition: width 0.3s ease;
            min-width: 50px;
        }}
        
        .progress-bar-text {{
            position: absolute;
            width: 100%;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: {verdict_color};
            font-weight: bold;
            pointer-events: none;
        }}
        
        .content {{
            padding: 40px;
        }}
        
        .area-section {{
            margin-bottom: 40px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            padding: 25px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }}
        
        .area-section:hover {{
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }}
        
        .area-header {{
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
            padding-bottom: 15px;
        }}
        
        .area-icon {{
            font-size: 2em;
            margin-right: 15px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: #f5f5f5;
        }}
        
        .area-title {{
            flex: 1;
        }}
        
        .area-title h2 {{
            color: #333;
            margin-bottom: 5px;
        }}
        
        .area-status {{
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            color: white;
            font-size: 0.9em;
        }}
        
        .area-details {{
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }}
        
        .items-list {{
            list-style: none;
        }}
        
        .items-list li {{
            display: flex;
            align-items: center;
            padding: 10px;
            margin-bottom: 8px;
            background: #f9f9f9;
            border-radius: 6px;
            border-left: 4px solid #e0e0e0;
        }}
        
        .items-list li.complete {{
            border-left-color: #28a745;
            background: #f0fff4;
        }}
        
        .items-list li.missing {{
            border-left-color: #dc3545;
            background: #fff5f5;
        }}
        
        .item-icon {{
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            margin-right: 12px;
            font-weight: bold;
            font-size: 0.9em;
        }}
        
        .item-icon.complete {{
            background: #28a745;
            color: white;
        }}
        
        .item-icon.missing {{
            background: #dc3545;
            color: white;
        }}
        
        .item-text {{
            flex: 1;
        }}
        
        .recommendations {{
            background: #f0f7ff;
            border-left: 4px solid #667eea;
            padding: 20px;
            border-radius: 6px;
            margin-top: 30px;
        }}
        
        .recommendations h3 {{
            color: #667eea;
            margin-bottom: 15px;
        }}
        
        .recommendations ol {{
            margin-left: 20px;
        }}
        
        .recommendations li {{
            margin-bottom: 10px;
            color: #555;
        }}
        
        .footer {{
            background: #f8f9fa;
            padding: 25px 40px;
            border-top: 1px solid #e0e0e0;
            text-align: center;
            color: #666;
            font-size: 0.9em;
        }}
        
        .score-badge {{
            display: inline-block;
            background: {verdict_color};
            color: white;
            padding: 12px 20px;
            border-radius: 25px;
            font-weight: bold;
            font-size: 1.1em;
            margin-left: 15px;
        }}
        
        .area-progress-bar {{
            width: 100%;
            height: 10px;
            background: #e9ecef;
            border-radius: 5px;
            overflow: hidden;
            margin-top: 10px;
        }}

        .area-progress-fill {{
            height: 100%;
            border-radius: 5px;
            transition: width 0.4s ease;
        }}

        .area-progress-label {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 4px;
            font-size: 0.8em;
            color: #888;
        }}

        .area-progress-pct {{
            font-weight: bold;
        }}

        @media (max-width: 768px) {{
            .header h1 {{
                font-size: 1.8em;
            }}
            
            .area-header {{
                flex-direction: column;
                align-items: flex-start;
            }}
            
            .area-status {{
                margin-top: 10px;
            }}
            
            .content {{
                padding: 20px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>DEFRA AI Standards Compliance Review</h1>
            <p><strong>Agent:</strong> {self.agent_name}</p>
            <div class="timestamp">Generated: {datetime.datetime.now().strftime("%d %B %Y at %H:%M:%S")}</div>
        </div>
        
        {summary_html}
        
        <div class="content">
            {areas_html}
            
            {recommendations_html}
            
            <div class="recommendations">
                <h3>📋 Next Steps</h3>
                <ul>
                    <li>Review all <span style="color: #dc3545;">non-compliant</span> items above</li>
                    <li>Work with your Data & Ethics Lead to address gaps</li>
                    <li>Document remediation plans for partial compliance areas</li>
                    <li>Schedule follow-up review after improvements</li>
                    <li>Contact DEFRA AI Tools Authority for guidance on tool selection and governance</li>
                </ul>
            </div>
        </div>
        
        <div class="footer">
            <p>DEFRA Compliance Review System | For questions, contact your Data & Ethics Lead or Governance Team</p>
        </div>
    </div>
</body>
</html>
"""
        return html
    
    def save_report(self, html: str = None) -> str:
        """Save HTML report to file."""
        if html is None:
            html = self.generate_html()
        
        filename = f"{self.agent_name.lower().replace(' ', '_')}_{self.timestamp}.html"
        filepath = self.report_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return str(filepath)


# Example usage
if __name__ == "__main__":
    # Create a sample report
    reporter = DefraComplianceReporter("Flood Risk Detection Agent")
    
    # Add assessments
    reporter.add_assessment(
        "System Type Selection",
        "COMPLIANT",
        "Agent correctly selected as AI Agent system type. Meets 4/5 checklist criteria including autonomous goal-driven decisions, real-time inputs, dynamic environment adaptation.",
        [
            {"name": "Autonomous goal-driven decisions", "description": "Detects flood risk events and triggers mitigation", "status": "COMPLETE"},
            {"name": "Dynamic environment", "description": "Adapts to real-time weather and water level data", "status": "COMPLETE"},
            {"name": "Real-time inputs", "description": "Monitors sensor feeds continuously", "status": "COMPLETE"},
            {"name": "Adaptation capability", "description": "Learns from past flood patterns", "status": "COMPLETE"},
        ]
    )
    
    reporter.add_assessment(
        "Responsible Design Principles",
        "PARTIAL",
        "Most principles addressed but transparency/explainability needs improvement.",
        [
            {"name": "Safe", "description": "Risk assessment completed with fallback mechanisms", "status": "COMPLETE"},
            {"name": "Effective", "description": "Success metrics defined and monitored", "status": "COMPLETE"},
            {"name": "Responsible", "description": "Clear ownership and DPIA completed", "status": "COMPLETE"},
            {"name": "Explainable", "description": "Decision logging in place but needs natural language summaries", "status": "MISSING"},
            {"name": "Fair", "description": "Fairness monitoring approach needs definition", "status": "MISSING"},
        ]
    )
    
    reporter.add_assessment(
        "Governance & Oversight",
        "COMPLIANT",
        "All key governance roles assigned. Required controls documented.",
        [
            {"name": "Business Owner", "description": "Assigned and accountable", "status": "COMPLETE"},
            {"name": "DPIA", "description": "Completed for personal location data", "status": "COMPLETE"},
            {"name": "Human Oversight Protocols", "description": "Defined for critical decisions", "status": "COMPLETE"},
            {"name": "Version Control", "description": "Git-based model versioning implemented", "status": "COMPLETE"},
        ]
    )
    
    reporter.add_assessment(
        "Technical & Delivery Guidance",
        "PARTIAL",
        "Architecture defined but post-deployment monitoring needs enhancement.",
        [
            {"name": "Governance by design", "description": "Fail-safes and monitoring defined", "status": "COMPLETE"},
            {"name": "Thorough testing", "description": "Real-world testing completed", "status": "COMPLETE"},
            {"name": "Data security", "description": "Data quality validated, encryption in place", "status": "COMPLETE"},
            {"name": "Monitoring & Alerting", "description": "Live dashboards implemented", "status": "COMPLETE"},
            {"name": "Post-deployment learning", "description": "Feedback loop planned but not yet operational", "status": "MISSING"},
        ]
    )
    
    reporter.add_assessment(
        "Security & Integration",
        "COMPLIANT",
        "Robust security measures in place. Integration with DEFRA systems via approved APIs.",
        [
            {"name": "Role-based access", "description": "Implemented for all dashboards", "status": "COMPLETE"},
            {"name": "Data encryption", "description": "Sensitive data encrypted in transit and at rest", "status": "COMPLETE"},
            {"name": "Audit logging", "description": "All decisions logged for compliance", "status": "COMPLETE"},
            {"name": "DEFRA compliance", "description": "Follows CDDO guidance", "status": "COMPLETE"},
        ]
    )
    
    # Add some sample recommendations
    reporter.add_recommendation(1, "Implement Natural Language Summaries", "Add explainability layer to Responsible Design principles - decision logging needs human-readable summaries")
    reporter.add_recommendation(2, "Define Fairness Monitoring", "Establish fairness metrics and monitoring approach for outcome parity across demographics")
    reporter.add_recommendation(3, "Activate Post-Deployment Learning", "Move post-deployment learning feedback loop from planning to operational status")
    
    # Save report
    filepath = reporter.save_report()
    print(f"Report saved to: {filepath}")
    print(f"Verdict: {reporter.calculate_overall_verdict()[0]}")
    print(f"Compliance Score: {reporter.calculate_overall_verdict()[1]:.0f}%")
